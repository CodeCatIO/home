MINWallPaper v1.1.0
===================
本地动态壁纸 / 音乐库 / 可编辑桌面组件（Windows 10/11 64 位）

本次更新
- 桌面组件支持多实例：时钟、音浪、文本、CPU / 内存 / GPU / 磁盘、图片，可自由拖动和缩放
- 时钟 10 种样式、音浪 10 种样式，颜色 / 字体 / 背景 / 灵敏度都可调
- 系统监控读取真实数据；图片组件支持单图、三图、轮播
- 视频壁纸改为最底层窗口，修复部分 Win11 桌面快照导致视频不显示的问题
- 单实例运行：重复打开只会唤出已打开的主面板

运行要求
- .NET 8 Desktop Runtime：https://dotnet.microsoft.com/download/dotnet/8.0
- WebView2 Runtime：Windows 11 自带；Windows 10 如未安装请从微软官网下载。
- 视频壁纸依赖系统 Media Foundation 解码，支持 mp4 / mkv / mov / avi / wmv 等常见格式。

使用
1. 解压到任意有写入权限的文件夹。
2. 双击 MINWallPaper.exe，托盘会出现图标。
3. 首次运行会在程序目录创建 data 文件夹：
   - data/wallpapers：放壁纸图片和视频
   - data/music/files：放音乐
   - data/music/playlists：播放列表
   - data/music_assignments.json：每张壁纸绑定的音乐
4. 打开面板后会自动扫描；也可以在界面里点“重新扫描”。
5. 视频壁纸本身静音；音乐由音乐库播放。组件在“工具库”里添加和编辑。
6. 播放视频时桌面图标会被视频画面盖住，这是当前视频层的限制；图标本身仍可点击。

本压缩包不包含任何个人壁纸、音乐或播放列表数据。
