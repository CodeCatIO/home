MINWallPaper v1.0
=================
本地动态壁纸 / 音乐库 / 桌面小工具（Windows 10/11 64 位）

运行要求
- .NET 8 Desktop Runtime：https://dotnet.microsoft.com/download/dotnet/8.0
- WebView2 Runtime：Windows 11 自带；Windows 10 如未安装请从微软官网下载。
- 视频壁纸依赖系统 Media Foundation 解码，支持 mp4 / mkv / mov / avi / wmv 等常见格式。

使用
1. 解压到任意有写入权限的文件夹。
2. 双击 MINWallPaper.exe，托盘会出现图标。
3. 首次运行会在程序目录创建 data 文件夹：
   - data/wallpapers：放壁纸图片和视频
   - data/music/files：放音乐
   - data/music/playlists：播放列表
   - data/music_assignments.json：每张壁纸绑定的音乐
4. 打开面板后会自动扫描；也可以在界面里点“重新扫描”。
5. 视频壁纸本身静音；音乐由音乐库播放。落雨、时钟、音浪在“工具库”里开关。

本压缩包不包含任何个人壁纸、音乐或播放列表数据。
